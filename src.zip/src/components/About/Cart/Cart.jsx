import React from 'react'

const Cart = ({title, desc, img}) => {
	return (
		<div className='cart'>
			<div className="cart_logo">
				<img src={img} alt="icon" />
			</div>
			<p className="cart_title">
				{title}
			</p>
			<p className="cart_desc">
				{desc}
			</p>
		</div>
	)
}

export default Cart