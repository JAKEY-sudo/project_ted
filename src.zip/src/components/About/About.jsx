import React from 'react'
import Cart from './Cart/Cart'
import { DataAbout } from '../../data'



const About = () => {
	return (
		<div className='about'>
			<h2 className="about_title">
				What makes our brand different
			</h2>
			{
				DataAbout.map(item => (
					<Cart 
						icon={item.img}
						title={item.title}
						desc={item.desc}
					/>
				))}
		</div>
	)
}

export default About